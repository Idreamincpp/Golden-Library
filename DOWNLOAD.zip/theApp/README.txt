
		██╗░░░░░██╗██████╗░██████╗░░█████╗░██████╗░██╗░░░██╗
da 		██║░░░░░██║██╔══██╗██╔══██╗██╔══██╗██╔══██╗╚██╗░██╔╝
golden		██║░░░░░██║██████╦╝██████╔╝███████║██████╔╝░╚████╔╝░
		██║░░░░░██║██╔══██╗██╔══██╗██╔══██║██╔══██╗░░╚██╔╝░░
		███████╗██║██████╦╝██║░░██║██║░░██║██║░░██║░░░██║░░░
		╚══════╝╚═╝╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░ app
 ____________________________________________________
|                                                    |
| HOW TO USE:                                        |
| >Add a book and storage location in the text boxes,|
|  and Click "Add Book".                             |
| >Find books by typing a keyword and clicking find  |
|  book. Updates will be available soon.             |
|____________________________________________________|

The .txt File containing all the books will be stored in the D:\ drive. Please
refer to that file to view all the books saved. It'll be a file called "lib.txt".

Please don't overload the program by spamclicking/etc.

The find button can only be used ONCE, for using it again restart the app.

The search is case sensitive, so if you add "Harry Potter" and search for "harry", it won't work. "Harry" will.

so, I hope you
Enjoy!

